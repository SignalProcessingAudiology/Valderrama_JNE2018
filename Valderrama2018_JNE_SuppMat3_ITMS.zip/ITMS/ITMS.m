function [y_enhanced,h,m,A,x_blink,SNR] = ITMS(y,h0,I,fs,DEBUG)
% [ITMS] Iterative Template Matching Suppression algorithm
% This Matlab/Octave function provides an estimation of the blink-artifact
% process (blink template, blink-events positions, blink-events amplitudes)
% from an input EEG, and removes the blink artifact from the EEG.
%
% INPUT:  [y]          EEG (column vector, N samples)
%         [h0]         Initial blink template (column vector, L samples)
%         [I]          Number of iterations (unitary value)
%         [fs]         Sampling frequency in Hz (unitary value in Hz)
%         [DEBUG]      flag for providing or not detailed info [1|0]
% OUTPUT: [y_enhanced] Enhanced EEG (column vector, N samples)
%         [h]          Normalized blink template (column vector, L samples)
%         [m]          Blink-event positions (in samples, column, K events)
%         [A]          Blink-event amplitudes (column, K events)
%         [x_blink]    Blink-artifact model (column vector, N samples)
%         [SNR]        Blink-to-EEG ratio (unitary value in dB)
%
% Please cite: Valderrama JT, de la Torre A, Van Dun B (2017). An
% automatic algorithm for blink-artifact suppression based on iterative 
% template matching: Application to single channel recording of cortical 
% auditory evoked potentials. Journal of Neural Engineering.

% Method parameters
h = h0;                        % Template initialized with h0
L = length(h);                 % Template length in samples
Fade = round(0.2*fs);          % Fade-in & -out number of samples (0.2 sec)
[b_lpf,a_lpf] = butter(4,2*20/fs); % Filter coefficients: 20 Hz LPF for h

% Iterations
for i=1:I
    % Matched filter h(-n) applied to the EEG
    z = filter(flipud(h),1,y);
    % Amplitudes and positions of local maxima in matched filter output
    [Z_LM,idx_LM] = local_maxima_estimation(z);
    % Threshold estimation from distribution of local maxima
    T = threshold_estimation(Z_LM,DEBUG);
    if isempty(T)    % If no threshold is detected, function terminates
        y_enhanced=y; h=zeros(L,1); m=[]; A=[]; x_blink=zeros(size(y));
        SNR=[]; return;
    end
    % Blink-events positions
    m = blink_event_positions(Z_LM,idx_LM,T,L,length(y));
    % Blink-artifact template estimated from EEG and blink positions
    h = template_estimation(y,m,L,Fade,b_lpf,a_lpf,DEBUG);
end
% Estimation of Blink-event amplitudes
A = amplitude_estimation(z,m,L,h);

% Estimation of blink model and suppression of blink artifact from EEG
impulses = zeros(size(y));      % Initialization
impulses(m) = A;                % Blink-events (positions and amplitudes)
x_blink = filter(h,1,impulses); % Convolution with template: blink model
y_enhanced = y-x_blink;         % Blink-artifact supression

% SNR estimate
Norm2 = filter(ones(size(h)),1,y.*y);
z_Norm2 = z.*z./Norm2;
z_Norm_k2 = z_Norm2(m+L-1);
SNR = 10*log10(mean(z_Norm_k2./(1-z_Norm_k2)));

if DEBUG
    clf(figure(53))
    DELTA = max(x_blink)-min(x_blink);
    plot([y+2*DELTA x_blink+DELTA y_enhanced]);
    legend('raw EEG','blink artifact estimates','enhanced EEG')
    xlabel('Time (Samples)'); ylabel('Amplitude');
    title(sprintf('SNR = %.2f dB\n',SNR))
    fprintf('SNR = %.2f dB\n',SNR);
end
return;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LOCAL FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Provides local maxima (amplitudes and positions)
function [X,idx_X] = local_maxima_estimation(x)
idx = (2:(length(x)-1))';                  % Samples index
cond = x(idx)>x(idx+1) & x(idx)>x(idx-1);  % Local maxima condition
X = x(cond);                               % Amplitudes of local maxima
idx_X = idx(cond);                         % Positions of local maxima
return;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Provides the threshold between the distribution of local maxima
% corresponding to noise (narrow mode around 0) and the distribution
% corresponding to the blink events (wide mode with bigger mean). The
% probability density function is estimated with a Gaussian kernel.
% DEBUG is a flag for providing or not detailed information.
function T = threshold_estimation(Ampl,DEBUG)
BW = 0.15*iqr(Ampl);                     % Bandwidth of the Kernel
domain = linspace(min(Ampl)-5*BW,max(Ampl)+5*BW,1000); % Axis of amplitudes
dA = domain(2)-domain(1);                % Step in the axis of amplitudes
Kernel = exp(-(-4.0*BW:dA:4.0*BW).^2/(2*BW*BW));  % Gaussian kernel
Kernel = Kernel/sum(Kernel);             % Kernel normalization
Histogram = histc(Ampl,domain);          % Amplitudes histogram
PDF = filtfilt(Kernel,1,Histogram);      % Kernel based prob. density funct
[pdf_max,idx_max]=max(PDF);       %#ok Mode around 0 corresponding to noise
idx = (2:(length(PDF)-1))';       % Search of local minima in pdf
cond = idx>idx_max & PDF(idx)<=PDF(idx-1) & PDF(idx)<PDF(idx+1);
if sum(cond)
    idx_T = min(idx(cond)); % First local minimum in pdf
    T = domain(idx_T);      % T: amplitude corresponding to this minimum
else
    T = [];                 % If no minimum is found, no threshold provided
    idx_T = [];
end
if DEBUG
    clf(figure(51))
    plot(domain,Histogram,'-b',domain,PDF,'.-r',T,PDF(idx_T),'*k')
    grid on;
    title('Threshold estimation')
    ylabel('Number of local maxima'); xlabel('Amplitude')
    legend('Histogram','Kernel-based pdf','Threshold')
end
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Provides the blink event positions (threshold is applied and group delay
% [L-1], associated to matched filter, is compensated).
function m = blink_event_positions(Z_LM,idx_LM,T,L,N)
m = idx_LM(Z_LM>T);                 % Blink-event positions
m = m-(L-1);                        % Group delay compensation
m = m(m>0 & m<N-L);                 % Triggers check:
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Estimates the blink artifact template from EEG (y) and the blink-event
% positions (m). This function also applies low-pass filtering, fade-in
% fade-out and normalization.
function h = template_estimation(y,m,L,Fade,B_lpf,A_lpf,DEBUG)
K = length(m);                      % Number of blink-events
H = zeros(L,K);                     % Matrix of sweeps
idx=1:L;                            % Index for the impulsive response h
for k=1:K
    idx1 = idx+m(k)-1;              % Index for current sweep
    Sweep = y(idx1);                % Sweeps selection
    H(idx,k) = Sweep-mean(Sweep);   % Demeaning & storage into H matrix
end
if K>1
    % Template estimation using only amplitudes between percentile 25-75
    H = sort(H,2);          % Amplitudes are sorted for removing outlayers
    i0 = round(K*0.25); i1=round(K*0.75); % 1st/3rd quartiles
    H = H(:,i0:i1);                       % Amplitudes between perc. 25-75
    W = hamming(length(i0:i1));           % Hamming window for averaging
    W = W/sum(W);                         % Window normalization
    h = H*W;                              % Template: average with window
else
    h = H;                                % If K=1, h=H
end
h = filtfilt(B_lpf,A_lpf,h);                % Filtered template
h(1:Fade) = h(1:Fade).*(0:Fade-1)'/Fade;    % Fade-in
h(end:-1:end-Fade+1) = h(end:-1:end-Fade+1).*(0:Fade-1)'/Fade; % Fade-out
h = h/sqrt(sum(h.*h));                      % Normalization
if DEBUG
    fprintf('%d blinks detected\n',K)
    clf(figure(52))
    plot(h,'.-')
    xlabel('Time (samples)'); ylabel('Amplitude'); grid on
    title(sprintf('Blink-artifact template (%d blink events detected)',K));
end
return;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Estimates the amplitudes from the local maxima
function A = amplitude_estimation(z,m,L,h)
Z = z(m+L-1);                               % Amplitudes estimates form z
K = length(m);                              % Number of blink-events
Rh = zeros(K,K);                            % B matrix initialization
Corr_h = xcorr(h);                          % Template autocorrelation
Corr_h = Corr_h(L:end);                     % 1-side autocorrelation
for k1=1:K
    for k2=1:K
        dt = round(abs(m(k2)-m(k1)));       % Time difference |m(k2)-m(k1)|
        if(dt<L), Rh(k1,k2) = Corr_h(dt+1); end
    end
end
A = Rh\Z;                                   % Amplitude estimates