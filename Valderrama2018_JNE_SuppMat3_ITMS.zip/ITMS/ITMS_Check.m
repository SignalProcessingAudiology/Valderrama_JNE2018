%% Script that tests the ITMS function
% Clear the workspace, clear the command window and close all figures
clear,clc,close all

% Load data: y. EEG, fs. sampling frequency
load('Data')

% Load initial template h
load('h0')

% Define the number of iterations
I = 10;

% Determine if we want to plot the figures [1. Yes | 0. No]
DEBUG = 1;

% Remove blinks with ITMS
[y_out,h,m,A,x_blink,SNR] = ITMS(y,h,I,fs,DEBUG);