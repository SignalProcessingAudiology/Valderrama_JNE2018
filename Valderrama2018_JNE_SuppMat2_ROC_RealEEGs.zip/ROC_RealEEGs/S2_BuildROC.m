%% Script that classifies blinks as TP, FP and FN at different thresholds
clear,clc,addpath(genpath('Algorithms'))

%% Variables initialization
load('Results/m_Real')              % Load the 'true' blink-events [run first script S1_DetermineTrueBlinks]
fs = 1000;                          % Sampling frequency
Channel_EEG = 17;                   % 17. Fz
SS = ['cba';'clm';'ega';'fsa';'gro';'hth';'lmi';'mba';'mma';'mta';'pla';'sce';'sph';'wpa'];
FF = ['01';'02';'03';'04';'05';'06';'07';'08';'09';'10';'11';'12';'13';'14'];
load('Template_Sbj01s1v13_EOG1');
[b,a] = butter(2,2*[1 30]/fs);      % EEG filter coefficients
I = 10;                             % Number of iterations in ITMS
T_ITMS = -0.98:0.02:1.01;           % Thresholds for ITMS
T_MSDW = 2:2:200;                   % Thresholds for MSDW
TP_ITMS = zeros(1,length(T_ITMS));    FP_ITMS = zeros(1,length(T_ITMS));
FN_ITMS = zeros(1,length(T_ITMS));    TP_MSDW = zeros(1,length(T_ITMS));
FP_MSDW = zeros(1,length(T_ITMS));    FN_MSDW = zeros(1,length(T_ITMS));
Duration = 0;                       % Accumulated EEG time in seconds
DEBUG = 0;                          % Flag to plot relevant results

%% Blinks classification
for Sbj=1:14
    for File1=1:2
        for File2=1:10
            % 0. Control: Only evaluate valid EEGs (those with valid blinks)
            fprintf(sprintf('Subject %d. Serial %d. File %d\n',Sbj,File1,File2))
            if(m_Real(1,Sbj,File1,File2)~=0)
                
                % 1. Load EEG
                F = loadcnt(['OpenDatabase/' SS(Sbj,:) '/' SS(Sbj,:)...
                    num2str(File1) 'ff' FF(File2,:) '.cnt']);
                Data = F.data';                 % Data referenced to Cz
                y = Data(:,Channel_EEG);        % Fz-Cz channel
                y = filtfilt(b,a,y);            % Filtered EEG
                if(Sbj==6 && File1==1),y = y/std(y)*6.5; end % Amplitude normalization
                Duration = Duration + length(y)/fs;     % Accumulated EEG time

                % 2. Check Real Blinks for the evaluated EEG [m]
                m = m_Real(m_Real(:,Sbj,File1,File2)>0,Sbj,File1,File2);
                y_Real = zeros(size(y)); y_Real(m) = max(y)*1.5;

                % 3. Classification of blinks detected by ITMS
                for Thr=1:length(T_ITMS)
                    [~,h_ITMS,m_ITMS,~,~] = ITMS_ROC(y,h0,I,fs,T_ITMS(Thr));
                    [~,Shift] = max(h_ITMS);    % Sample of blink-template maximum
                    m_ITMS = m_ITMS+Shift;      % Blink-events shifted to the maximum
                    TP = [];        FN = [];        FP = [];
                    for k=1:length(m)
                        aux = abs(m_ITMS-m(k));
                        Idx = find(aux<100);
                        if isfinite(Idx), TP = [TP;k];  %#ok Correctly detected
                        else FN = [FN;k]; end           %#ok Not detected
                    end
                    for k=1:length(m_ITMS)
                        aux = abs(m-m_ITMS(k));
                        Idx = find(aux<100);
                        if isempty(Idx), FP = [FP;k]; end %#ok Incorrectly detected
                    end
                    TP_ITMS(:,Thr) = TP_ITMS(:,Thr)+size(TP,1);
                    FN_ITMS(:,Thr) =  FN_ITMS(:,Thr)+size(FN,1);
                    FP_ITMS(:,Thr) =  FP_ITMS(:,Thr)+size(FP,1);
                    fprintf('File [%d %d %d].   ITMS: %.2f\t\tTP: %d\t\tFN: %d\t\tFP: %d\n',...
                        Sbj,File1,File2,T_ITMS(Thr),size(TP,1),size(FN,1),size(FP,1))
                    if(DEBUG)
                        clf(figure(10)),zoom on,hold on,box on
                        stem(m(TP),max(y)*1.2*ones(size(TP)),'g')
                        stem(m_ITMS(FP),max(y)*1.2*ones(size(FP)),'k')
                        stem(m(FN),max(y)*1.2*ones(size(FN)),'r')
                        plot([y y_Real])
                        ylabel('Amplitude'),xlabel('Sample')
                        title(sprintf(['ITMS.    Valid [Brown]: %d.    TP [green]: %d.'...
                            '    FP [black]: %d.    FN [red]: %d'],length(m),length(TP),length(FP),length(FN)))
                        pause(0.1)
                    end
                end

                % 4. Classification of blinks detected by MSDW
                for Thr=1:length(T_MSDW)
                    [range,~,~] = MSDW(y,fs,T_MSDW(Thr));
                    range = round(range/62.5*1000);
                    m_MSDW = zeros(size(range,1),1);
                    for k=1:length(m_MSDW)
                        if(range(k,1)>range(k,2)),range(k,:) = fliplr(range(k,:));end
                        [~,Idx] = max(y(range(k,1):range(k,2)));
                        m_MSDW(k) = range(k,1)+Idx;
                    end
                    TP = [];        FN = [];        FP = [];
                    for k=1:length(m)
                        aux = abs(m_MSDW-m(k));
                        Idx = find(aux<100);
                        if isfinite(Idx), TP = [TP;k];        %#ok
                        else FN = [FN;k]; end                 %#ok
                    end
                    for k=1:length(m_MSDW)
                        aux = abs(m-m_MSDW(k));
                        Idx = find(aux<100);
                        if isempty(Idx), FP = [FP;k]; end     %#ok
                    end
                    TP_MSDW(:,Thr) = TP_MSDW(:,Thr)+size(TP,1);
                    FN_MSDW(:,Thr) =  FN_MSDW(:,Thr)+size(FN,1);
                    FP_MSDW(:,Thr) =  FP_MSDW(:,Thr)+size(FP,1);
                    fprintf('File [%d %d %d].   MSDW: %.2f\t\tTP: %d\t\tFN: %d\t\tFP: %d\n',...
                        Sbj,File1,File2,T_MSDW(Thr),size(TP,1),size(FN,1),size(FP,1))
                    if(DEBUG)
                        clf(figure(10)),zoom on,hold on,box on
                        stem(m(TP),max(y)*1.2*ones(size(TP)),'g')
                        stem(m_MSDW(FP),max(y)*1.2*ones(size(FP)),'k')
                        stem(m(FN),max(y)*1.2*ones(size(FN)),'r')
                        plot([y y_Real])
                        ylabel('Amplitude'),xlabel('Sample')
                        title(sprintf(['MSDW.    True [Brown]: %d.    TP [green]: %d.'...
                            '    FP [black]: %d.    FN [red]: %d'],length(m),length(TP),length(FP),length(FN)))
                        pause(0.1)
                    end
                end
            end
        end
    end
end

%% Save results
save('Results/ROC_Real','TP_ITMS','FP_ITMS','FN_ITMS','TP_MSDW','FP_MSDW','FN_MSDW','Duration')