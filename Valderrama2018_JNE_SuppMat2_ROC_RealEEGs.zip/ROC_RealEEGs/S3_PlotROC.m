%% Script that generates figure 3
clear,clc,close all,addpath(genpath('Algorithms'))

%% Variables initialization
fs=1000;    FS = 11;    MS = 9;     LW = 1;     MW = 1.0;
cmp = [80  80  80; 160 160 160; 50  50 50]/255;             % Colormap
load('Results/ROC_Real')    % ROC data [run first script S2_BuildROC]

% Estimate TPR and FPPS for ITMS
TPR = TP_ITMS./(TP_ITMS+FN_ITMS);
FPPS = FP_ITMS/Duration;

% Estimate TPR an FPPS for MSDW
TPR_MSDW = TP_MSDW./(TP_MSDW+FN_MSDW);
FPPS_MSDW = FP_MSDW/Duration;

%% Generate figure
figure('PaperSize',[15 10]),box on,grid on,hold on
plot(FPPS,TPR*100,'.-','Color',cmp(1,:),'MarkerSize',MS)
plot(FPPS_MSDW,TPR_MSDW*100,'.-','Color',cmp(2,:),'MarkerSize',MS)
plot(FPPS(50),TPR(50)*100,'*','Color',cmp(1,:),'MarkerSize',MS,'LineWidth',MW)
plot(FPPS_MSDW(65),TPR_MSDW(65)*100,'p','Color',cmp(2,:),'MarkerSize',MS,'LineWidth',MW)  % Thr=130
plot(FPPS_MSDW(40),TPR_MSDW(40)*100,'v','Color',cmp(2,:),'MarkerSize',MS,'LineWidth',MW)   % Thr=80
plot(FPPS_MSDW(30),TPR_MSDW(30)*100,'o','Color',cmp(2,:),'MarkerSize',MS,'LineWidth',MW)   % Thr=60
plot(FPPS_MSDW(20),TPR_MSDW(20)*100,'*','Color',cmp(2,:),'MarkerSize',MS,'LineWidth',MW)   % Thr=40
h = legend('ITMS','MSDW','Location','SouthEast');
set(h,'FontSize',FS-1)
set(gca,'ytick',75:5:100,'FontSize',FS-1)
axis([0 0.30 75 100])
ylabel('TPR (%)','FontSize',FS)
xlabel('FPPS','FontSize',FS)
title('ROC [Real data]','FontSize',FS)
fprintf('ITMS:\t\t\tTPR %.2f\t\tFPPS %.3g\n',TPR(50)*100,FPPS(50))
fprintf('MSDW_40:\t\tTPR %.2f\t\tFPPS %.3g\n',TPR_MSDW(20)*100,FPPS_MSDW(20))
fprintf('MSDW_60:\t\tTPR %.2f\t\tFPPS %.3g\n',TPR_MSDW(30)*100,FPPS_MSDW(30))
fprintf('MSDW_80:\t\tTPR %.2f\t\tFPPS %.3g\n',TPR_MSDW(40)*100,FPPS_MSDW(40))
fprintf('MSDW_130:\t\tTPR %.2f\t\tFPPS %.3g\n',TPR_MSDW(65)*100,FPPS_MSDW(65))

orient tall
print('-dpng','-r600','Results/Figure4')
print('-depsc2','-r600','Results/Figure4')
% close all