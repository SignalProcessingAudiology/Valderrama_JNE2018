function [y_enhanced,h,m,A,x_blink] = ITMS_ROC(y,h0,I,fs,Threshold)
% [ITMS] Iterative Template Matching Suppression algorithm
% INPUT:  [y]           EEG (column vector)
%         [h0]          Predefined blink-artifact template (column vector)
%         [I]           Number of iterations (unitary value)
%         [fs]          Sampling frequency in Hz (unitary value)
% OUTPUT: [y_enhanced]  Enhanced EEG (column vector)
%         [h]           Normalized blink-artifact template (column vector)
%         [m]           Blink-events (column vector)
%         [A]           Blink-event amplitudes (column vector)
%         [x_blink]     Blink-artifact model (column vector)
%
% Please cite: Valderrama JT, de la Torre A, Van Dun B, Dillon H (2017). An
% automatic algorithm for blink-artifact suppression with iterative
% template matching. Journal of Neural Engineering.

% Method parameters:
h = h0;                             % Template initialize with h0
L = length(h);                      % Template length in samples
Fade = round(0.2*fs);               % Fade-in & -out number of samples
[b,a] = butter(4,2*20/fs);          % Filter coefficients: 20 Hz LPF
N = length(y);                      % Number of samples of the EEG

% Iterations: Processes 1 & 2
for i=1:I
    % Matched filter h(-n) applied to the EEG [there is a group delay]
    z = filter(flipud(h),1,y);
    
    % Local maxima (LM) in z: Amplitudes (A_LM) and positions (idx_LM)
    idx = (2:(N-1))';                               % Samples index
    cond = z(idx)>z(idx+1) & z(idx)>z(idx-1);       % Local maxima (LM)
    A_LM = z(cond);                                 % LM amplitudes
    idx_LM = idx(cond);                             % LM positions
    
    % f: Fitted function to the A_LM distribution using a Normal kernel
    BW = 0.15*iqr(A_LM);                % Bandwidth of the Kernel
    Domain = linspace(min(A_LM)-5*BW,max(A_LM)+5*BW,1000);
    dx = Domain(2)-Domain(1);           % Sample step in the Kernel Domain
    Kernel = exp(-(-4.0*BW:dx:4.0*BW).^2/(2*BW*BW));    % Normal kernel
    Kernel = Kernel/sum(Kernel);        % Kernel normalization
    Histogram = histc(A_LM,Domain);     % A_LM histrogram
    f = filtfilt(Kernel,1,Histogram);   % Fitted function
    
    % T: Automatic threshold estimate
    [~,idx_max] = max(f);               % 1st mode position [Noise distr]
    idx = (2:(length(f)-1))';           % Samples index
    cond = idx>idx_max & f(idx)<=f(idx-1) & f(idx)<f(idx+1); % Minima search
    if(isfinite(cond))                  % If detected minimum
        T = Domain(min(idx(cond)));     % Threshold: 1st local minimum
    else                                % Otherwise, no blinks are detected
        y_enhanced = y;
        h = zeros(L,1);
        m = [];
        A = [];
        x_blink = zeros(size(y));
        return                          % End of the function
    end

    % Threshold adjustment
    if(i==I)
        if(Threshold<0), T = T+Threshold*T; end
        if(Threshold>0), T = T+Threshold*(max(A_LM)-T); end
        m = idx_LM(A_LM>T);                 % Blink-event positions
        m = m-(L-1);                        % Group delay compensation
        m = m(m>0 & m<length(y)-L);         % Blink-events check
        y_enhanced = y;
%         h = zeros(L,1);
        A = [];
        x_blink = zeros(size(y));
        return
    end
    
    % m: Blink-events position
    m = idx_LM(A_LM>T);                 % Blink-event positions
    m = m-(L-1);                        % Group delay compensation
    m = m(m>0 & m<length(y)-L);         % Blink-events check
    K = length(m);                      % Number of blink-events

    % Blink-artifact template [hi]
    H = zeros(L,K);                     % H: Matrix of sweeps
    for k=1:K
        Sweep = y(m(k):m(k)+L-1);       % Sweeps selection
        H(:,k) = Sweep-mean(Sweep);     % Demeaning and storing in H matrix
    end
    switch 1       % Select [1] Q1-Q3 average, [2] Median
        case 1     % Only amplitudes between percentile 25-75 are preserved
            if K>1                          % K must be greater than 1
                H = sort(H,2);              % Amplitudes sorting
                i0 = round(K*0.25);         % 1st quartile (25%)
                i1 = round(K*0.75);         % 3rd quartile (75%)
                W = hamming(length(i0:i1)); % Hamming window
                W = W/sum(W);               % Window normalization
                h = H(:,i0:i1)*W;           % h: average (with window)
            else
                h = H;                      % h = H if K equal to 1
            end
        case 2                              % Median
            h = median(H,2);                % Median of sweeps
    end
    h = filtfilt(b,a,h);                        % Filtered template
    h(1:Fade) = h(1:Fade).*(0:Fade-1)'/Fade;    % Fade-in
    h(end:-1:end-Fade+1) = h(end:-1:end-Fade+1).*(0:Fade-1)'/Fade; % F-out
    h = h/sqrt(sum(h.*h));                      % Normalization
end
return;