%% Script that automatically determines the 'true' blink-events from 
clear,clc, addpath(genpath('Algorithms'))

%% Variables initialization
fs = 1000;                      % Sampling frequency
SS = ['cba';'clm';'ega';'fsa';'gro';'hth';'lmi';'mba';'mma';'mta';'pla';'sce';'sph';'wpa'];
FF = ['01';'02';'03';'04';'05';'06';'07';'08';'09';'10';'11';'12';'13';'14'];
Channel_EEG = 1;                % Channel 1 is FP1 (in the vertical of the eye)
Threshold_MSDW = 60;            % Threshold for best-performance in MSDW
load('Template_Sbj01s1v13_EOG1');   % Initial template for Neuroscan EEGs
[b,a] = butter(2,2*[1 30]/fs);  % EEG filter coefficients
I = 10;                         % Number of iterations in ITMS
DEBUG = 1;                      % Flag to plot relevant results
m_Real = zeros(1e3,14,2,10);    % Format: 1.Blinks, 2.Sbj, 3.File1, 4.File2

%% Blink-events detection
for Sbj=1:14                    % Loop in the subjects
    for File1=1:2               % Loop in days: day 1 and day 2
        for File2=1:10          % Loop in files: first 10 files per day
            % 10 files (all File2 files) from File1 in Subject 6 are excluded
            % because they are not propperly calibrated
            if ~(Sbj==6 && File1==1)
                % 0. Control
                fprintf(sprintf('Subject %d/14, File1 %d/2, File2 %d/10\n',Sbj,File1,File2))

                % 1. Load EEG
                F = loadcnt(['OpenDatabase/' SS(Sbj,:) '/' SS(Sbj,:)...
                    num2str(File1) 'ff' FF(File2,:) '.cnt']);
                Data = F.data';                 % Data referenced to Cz
                y = Data(:,Channel_EEG);        % FP1-Cz channel
                y = filtfilt(b,a,y);            % Filtered EEG

                % 2. Blinks detected by ITMS
                [~,h,m,~,~,SNR] = ITMS(y,h0,I,fs,DEBUG); % m: Blink-events start
                [~,Shift] = max(h);   % Shift: Sample of blink-template maximum
                m = m+Shift;          % m: Blink-events shifted to the maximum
                if(DEBUG),figure(52),hold on,plot(h0/sqrt(sum(h0.*h0)));end %#ok

                if SNR>=6            
                    % 3. Blinks detected by MSDW
                    [range,~,~] = MSDW(y,fs,Threshold_MSDW);
                    range = round(range/62.5*fs);

                    % 4. Search for coincidences in both methods
                    idx=1;
                    for k1=1:length(m)
                        Coincidences = sum(m(k1)>range(:,1) & m(k1)<range(:,2));
                        if Coincidences
                            m_Real(idx,Sbj,File1,File2) = m(k1);
                            idx = idx+1;
                        end
                    end; clear k1
                    
                    % 5. Requirement of at least 10 blinks per EEG
                    if(idx<=10), m_Real(:,Sbj,File1,File2) = 0; end
                end

                % 6. DEBUG figure
                if(DEBUG && SNR>=6 && idx>10)
                    aux = zeros(size(y)); aux(m) = 150;
                    aux2 = zeros(size(y)); aux2(m_Real(1:idx-1,Sbj,File1,File2)) = 200;
                    clf(figure(1)),plot([y,aux2,aux]),hold on
                    for k=1:size(range,1)
                        plot(range(k,1):range(k,2),y(range(k,1):range(k,2)),'k');
                    end
                    title(sprintf('True blinks: %d.    ITMS: %d.    MSDW: %d',...
                        idx-1,length(m),size(range,1)))
                    ylabel('Amplitude'),xlabel('Sample')
                    legend('EOG','True','ITMS','MSDW','Location','NorthEast')
                    fprintf('PRESS A KEY TO CONTINUE\n'),pause
                elseif(DEBUG && (SNR<6 || idx<=10))
                    clf(figure(10)),title('EEG not valid'), pause,
                end
            end
        end
    end
end

%% Store the result
save('Results/m_Real','m_Real')